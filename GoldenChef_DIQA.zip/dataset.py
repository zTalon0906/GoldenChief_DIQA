import os
import random
import pandas as pd
from PIL import Image
import torch
from torch.utils import data
import numpy as np
from torchvision import transforms


class ImageDataset_Diqa(data.Dataset):
    def __init__(self, data_dir, filename_path, transform, resize, frames, database_name, feat_dir):
        super(ImageDataset_Diqa, self).__init__()

        dataInfo = pd.read_csv(filename_path)
        length = len(dataInfo['res'].tolist())

        seed = 20250611
        random.seed(seed)
        np.random.seed(seed)
        index_rd = np.random.permutation(length)
        train_source = index_rd[:int(length * 0.9)]
        val_source = index_rd[int(length * 0.9):]
        if database_name == 'train':
            self.Image_names = dataInfo.iloc[train_source]['res'].tolist()
            self.score1 = dataInfo.iloc[train_source]['overall'].tolist()
            self.score2 = dataInfo.iloc[train_source]['sharpness'].tolist()
            self.score3 = dataInfo.iloc[train_source]['color_fidelity'].tolist()

        elif database_name == 'val':
            self.Image_names = dataInfo.iloc[val_source]['res'].tolist()
            self.score1 = dataInfo.iloc[val_source]['overall'].tolist()
            self.score2 = dataInfo.iloc[val_source]['sharpness'].tolist()
            self.score3 = dataInfo.iloc[val_source]['color_fidelity'].tolist()
        self.resize = resize
        self.data_dir = data_dir
        self.transform = transform
        self.length = len(self.Image_names)
        self.frames = frames


    def __len__(self):
        return self.length

    def __getitem__(self, idx):

        Image_name = str(self.Image_names[idx])
        # Image_name_str = str(self.Image_names[idx])
        Image_score1 = torch.FloatTensor(np.array(float(self.score1[idx])))
        Image_score2 = torch.FloatTensor(np.array(float(self.score2[idx])))
        Image_score3 = torch.FloatTensor(np.array(float(self.score3[idx])))

        frames_path = os.path.join(self.data_dir, Image_name)
        image = Image.open(frames_path)
        resize_transform = transforms.Resize((self.resize, self.resize))

        resize_transform2 = transforms.Resize((1280, 1280))
        resized_image = resize_transform2(image)
        resized_image_tensor2 = self.transform(resized_image)
 
        transformed_rs = torch.zeros([self.frames, 3, self.resize, self.resize])
        crop = transforms.RandomCrop((self.resize, self.resize))


        # 分成5*5个224×224的patch
        for i in range(4):  # 行
            for j in range(4):  # 列
                # 计算每个块的左上角坐标
                left = j * 256
                upper = i * 256
                right = left + 256
                lower = upper + 256

                transformed_rs[i*4+j] = crop(resized_image_tensor2[:, upper:lower, left:right])

        return transformed_rs, Image_score1, Image_score2, Image_score3, Image_name






