import time
import argparse
import DIQAModel
from thop import profile
from torchvision import transforms
# from pytorchvideo.models.hub import slowfast_r50
from PIL import Image
import cv2
import torch
import torch.nn as nn
import torchvision.models as models
import numpy as np



def image_process(image_dir, frames, resize):

    image = Image.open(image_dir)
    resize_transform = transforms.Resize((1280, 1280))
    resized_image = resize_transform(image)
    transformations = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    resized_image_tensor = transformations(resized_image)

    transformed_rs = torch.zeros([frames, 3, resize, resize])
    crop = transforms.RandomCrop((resize, resize))

    # 分成5*5个224×224的patch
    for i in range(5):  # 行
        for j in range(5):  # 列
            # 计算每个块的左上角坐标
            left = j * 256
            upper = i * 256
            right = left + 256
            lower = upper + 256
            transformed_rs[i * 5 + j] = crop(resized_image_tensor[:, upper:lower, left:right])

    return transformed_rs.unsqueeze(0)




def main(config):
    device = torch.device("cpu")
    model = DIQAModel.DIQA_model()
    pretrained_weights_path = config.Model_weights_path
    if pretrained_weights_path:
        try:
            model.load_state_dict(torch.load(pretrained_weights_path, map_location=device, weights_only=True), strict=False)
            print(f"成功加载预训练权重: {pretrained_weights_path}")
        except Exception as e:
            print(f"加载预训练权重时出错: {e}")

    model.eval()
    model.float()
    model.to(device)

    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    try:
        images = image_process(config.image_dir, config.frames, config.resize)
        session_start_test = time.time()
        output = model(images)
        print('得分为：', output)
        session_end_test = time.time()
        print('CostTime: {:.4f}'.format(session_end_test - session_start_test))
        flops, params = profile(model, inputs=(images.to(device), ))
        print(f"Total GFLOPs: {flops / 1e9}")
    except Exception as e:
        print(f"出错: {e}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--image_dir', type=str, default=r'/data/coding/train/res/train_res_00001.jpg')
    parser.add_argument('--frames', type=int, default=25)
    parser.add_argument('--Model_weights_path', type=str, default='weights/GoldenChef_Diqa_model.pth')
    parser.add_argument('--resize', type=int, default=224)
    config = parser.parse_args()
    main(config)
