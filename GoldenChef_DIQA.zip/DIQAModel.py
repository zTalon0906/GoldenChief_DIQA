import torch
import torch.nn as nn
import torchvision.models as models
from thop import profile
import numpy as np
from torchvision.models.swin_transformer import PatchMergingV2
import torch.nn.functional as F
import cv2
import torch.nn.functional as F
import math





def base_quality_regression2(in_channels, middle_channels, out_channels):
    regression_block = nn.Sequential(
        nn.Linear(in_channels, middle_channels),
        nn.ReLU(),
        # nn.Dropout(0.15),
        nn.Linear(middle_channels, out_channels),

    )
    return regression_block


class ConvNeXtFeatureExtractor2(nn.Module):
    def __init__(self, backbone, layer_indices=[1, 3, 5, 7]):
        super().__init__()
        self.features = backbone.features
        self.feature_outputs = {}
        self._register_hooks(layer_indices)

    def _register_hooks(self, layer_indices):
        def save_feature_hook(layer_id):
            def hook(_, __, output):
                self.feature_outputs[layer_id] = output.detach()
            return hook

        self.hooks = []
        for idx in layer_indices:
            hook = self.features[idx].register_forward_hook(save_feature_hook(idx))
            self.hooks.append(hook)

    def forward(self, x):
        self.feature_outputs.clear()
        x = self.features(x)
        return {"features": [self.feature_outputs.get(1), self.feature_outputs.get(3),
                             self.feature_outputs.get(5), self.feature_outputs.get(7)], "final_feature": x}

    def remove_hooks(self):
        for hook in self.hooks:
            hook.remove()
        self.hooks.clear()


class SwinTransformerFeatureExtractor(nn.Module):
    def __init__(self, backbone, layer_indices=[1, 3, 5, 7]):
        super().__init__()
        self.features = backbone.features
        self.feature_outputs = {}
        self._register_hooks(layer_indices)

    def _register_hooks(self, layer_indices):
        def save_feature_hook(layer_id):
            def hook(_, __, output):
                self.feature_outputs[layer_id] = output.detach()
            return hook

        self.hooks = []
        for idx in layer_indices:
            hook = self.features[idx].register_forward_hook(save_feature_hook(idx))
            self.hooks.append(hook)

    def forward(self, x):
        self.feature_outputs.clear()
        x = self.features(x)
        return {"features": [self.feature_outputs.get(idx) for idx in sorted(self.feature_outputs.keys())], "final_feature": x}

    def remove_hooks(self):
        for hook in self.hooks:
            hook.remove()
        self.hooks.clear()

class ChannelAttention1(nn.Module):
    def __init__(self, in_planes, reduction=8):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(in_planes, in_planes // reduction),
            nn.ReLU(inplace=True),
            nn.Linear(in_planes // reduction, in_planes),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)


class FusionBlock(nn.Module):
    def __init__(self, channels=192):
        super().__init__()
        # 不同空洞率的卷积分支
        self.dconv1 = nn.Conv2d(channels, channels, 3, padding=1, dilation=1)
        self.dconv2 = nn.Conv2d(channels, channels, 3, padding=2, dilation=2)
        self.dconv3 = nn.Conv2d(channels, channels, 3, padding=3, dilation=3)

        # 特征融合后的通道注意力
        self.ca = ChannelAttention1(channels * 3)

        # 最后的1x1卷积调整通道
        self.pooling = nn.AvgPool2d(2, stride=2)
        self.conv_final = nn.Conv2d(channels * 3, channels * 2, 1)

    def forward(self, x1):
        # 处理第一个输入特征
        x1_1 = self.dconv1(x1)
        # print(f"x1_1 shape: {x1_1.shape}")
        x1_2 = self.dconv2(x1)
        # print(f"x1_2 shape: {x1_2.shape}")
        x1_3 = self.dconv3(x1)
        # print(f"x1_3 shape: {x1_3.shape}")
        # x1 = x1_1 + x1_2 + x1_3  # 特征融合方式1：相加
        # print(f"x1 shape: {x1.shape}")
        x = torch.cat([x1_1, x1_2, x1_3], dim=1)  # 特征融合方式2：拼接

        # 处理第二个输入特征
        # x2_1 = self.dconv1(x2)
        # x2_3 = self.dconv3(x2)
        # # print(f"x2_1 shape: {x2_1.shape}")
        # x2 = x2_1 + x2_3  # 特征融合方式2：相加
        #
        # # 拼接两个特征
        # fused = torch.cat([x1, x2], dim=1)

        # 通道注意力增强
        weighted = self.ca(x) + x  # 相加
        # print(f"weighted shape: {weighted.shape}")

        # 通道维度融合
        return self.pooling(self.conv_final(weighted))




class DIQA_model(torch.nn.Module):
    def __init__(self, device=torch.device("cuda" if torch.cuda.is_available() else "cpu")):
        super(DIQA_model, self).__init__()

        model = models.swin_v2_t(weights='Swin_V2_T_Weights.DEFAULT')
        self.spatial_feature_extraction = SwinTransformerFeatureExtractor(model)
        convnext = models.convnext_tiny(weights='ConvNeXt_Tiny_Weights.DEFAULT')
        # self.convnext = torch.nn.Sequential(*list(convnext.children())[:-1])
        self.convnext = ConvNeXtFeatureExtractor2(convnext)

        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fusion_block1 = FusionBlock(channels=192)
        self.fusion_block2 = FusionBlock(channels=384)
 

        self.downsample1 = nn.Sequential(
            nn.Conv2d(192, 192, 3, stride=2, padding=1, groups=192),  # 深度卷积
            nn.Conv2d(192, 384, 1),  # 逐点卷积
            nn.BatchNorm2d(384),
            nn.ReLU()
        )

        self.downsample = nn.Sequential(
            nn.Conv2d(192, 192, 3, stride=2, padding=1, groups=192),  # 深度卷积
            nn.Conv2d(192, 384, 1),  # 逐点卷积
            nn.BatchNorm2d(384),
            nn.ReLU(),
            nn.Conv2d(384, 384, 3, stride=2, padding=1, groups=384),
            nn.Conv2d(384, 768, 1),  # 逐点卷积
            nn.BatchNorm2d(768),
            nn.ReLU()
        )

        self.downsample2 = nn.Sequential(
            nn.Conv2d(384, 384, 3, stride=2, padding=1, groups=384),  # 深度卷积
            nn.Conv2d(384, 768, 1),  # 逐点卷积
            nn.BatchNorm2d(768),
            nn.ReLU()
        )

       
        self.MLP1 = base_quality_regression2(in_channels=2304, middle_channels=128, out_channels=1)
        self.MLP2 = base_quality_regression2(in_channels=1152, middle_channels=128, out_channels=1)  # 1056
        self.MLP3 = base_quality_regression2(in_channels=1536, middle_channels=128, out_channels=1)
        self.device = device

    def forward(self, x):
        # input dimension: batch x frames x 3 x height x width
        x_size = x.shape
        B, T, C, H, W = x_size[0], x_size[1], x_size[2], x_size[3], x_size[4]
        x = x.reshape(-1, C, H, W)

        y_features = self.spatial_feature_extraction(x)
        convnext_layers_feature = self.convnext(x)

        convnext_layers = [convnext_layers_feature['features'][i] for i in range(0, 3)]

        Hooks = [y_features['features'][0], y_features['features'][1], y_features['features'][2], y_features['features'][3]]
        Hooks = [hook.permute(0, 3, 1, 2) for hook in Hooks]
  

        Fusion_feature1 = self.fusion_block1((Hooks[1] + convnext_layers[1]))  # torch.Size([16, 384, 14, 14])
        Fusion_feature2 = self.fusion_block2(Hooks[2] + Fusion_feature1 + convnext_layers[2])  # torch.Size([16, 768, 7, 7])

        final_feature = torch.mean(self.avg_pool(torch.cat([Fusion_feature2, convnext_layers_feature['final_feature'],
                                                            y_features['final_feature'].permute(0, 3, 1, 2)],  dim=1)).reshape(B, T, -1), dim=1)

    
        score1 = self.MLP1(final_feature)
        
        Fusion_feature1_pooled = self.avg_pool(Fusion_feature1)
        convnext_final_feature_pooled = self.avg_pool(convnext_layers_feature['final_feature'])

        # 将池化后的特征重塑为 (B * T, -1) 的形状
        Fusion_feature1_pooled = Fusion_feature1_pooled.reshape(B, T, -1)
        convnext_final_feature_pooled = convnext_final_feature_pooled.reshape(B, T, -1)

        # 在时间维度（dim=1）上对两个特征进行平均
        Fusion_feature1_pooled = Fusion_feature1_pooled.mean(dim=1)
        convnext_final_feature_pooled = convnext_final_feature_pooled.mean(dim=1)

        # 拼接池化后的特征
        score2_feature = torch.cat([Fusion_feature1_pooled, convnext_final_feature_pooled], dim=1)

        # 将拼接后的特征输入到 MLP2 中计算 score2
        score2 = self.MLP2(score2_feature)

        # 修改 score3 的计算
        score3_feature = torch.cat([Fusion_feature2, y_features['final_feature'].permute(0, 3, 1, 2)], dim=1)
        score3_feature = self.avg_pool(score3_feature).reshape(B, T, -1).mean(dim=1)
        score3 = self.MLP3(score3_feature)

        return score1.squeeze(1), score2.squeeze(1), score3.squeeze(1)





if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = DIQA_model().to(device)
    model = model.float()

    input_sample = (torch.randn(1, 25, 3, 224, 224).to(device),)  # z
    flops, params = profile(model, inputs=input_sample)

    # flops= count_gflops_with_fvcore(model, input_sample)
    print(f"Total GFLOPs: {flops / 1e9}")
    print(f"Total params: {params / 1e6}")
