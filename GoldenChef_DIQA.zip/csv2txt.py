import csv

def csv_to_txt(csv_file, txt_file):
    """
    将CSV文件转换为TXT文件。

    :param csv_file: 输入的CSV文件路径
    :param txt_file: 输出的TXT文件路径
    """
    try:
        # 打开CSV文件进行读取
        with open(csv_file, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            # 读取CSV文件的所有行
            lines = [line for line in reader]

        # 打开TXT文件进行写入
        with open(txt_file, mode='w', encoding='utf-8') as txtfile:
            # 将CSV文件的内容逐行写入TXT文件
            for line in lines:
                txtfile.write(','.join(line) + '\n')  # 保留CSV的逗号分隔格式

        print(f"CSV文件已成功转换为TXT文件：{txt_file}")
    except FileNotFoundError:
        print(f"错误：文件 {csv_file} 不存在")
    except Exception as e:
        print(f"发生错误：{e}")

# 示例用法
csv_file = 'prediction.csv'
txt_file = 'output.txt'
csv_to_txt(csv_file, txt_file)