import os
import cv2
from torch.utils import data
from PIL import Image
import pandas as pd
import torch
from torchvision import transforms
import time
import numpy as np
import argparse
import DIQAModel
from utils import performance_fit
# import clip
import random
import torch.nn.functional as F




class ImageDataset_Diqa(data.Dataset):
    def __init__(self, data_dir, filename_path, transform, resize, frames, feat_dir=''):
        super(ImageDataset_Diqa, self).__init__()

        dataInfo = pd.read_csv(filename_path)

        self.Image_names = dataInfo['res'].tolist()

        self.resize = resize
        self.videos_dir = data_dir
        self.transform = transform
        self.length = len(self.Image_names)
        self.frames = frames


        self.feat_dir = feat_dir

    def __len__(self):
        return self.length

    def __getitem__(self, idx):

        Image_name = str(self.Image_names[idx])

        frames_path = os.path.join(self.videos_dir, Image_name)
        image = Image.open(frames_path)

        resize_transform2 = transforms.Resize((1280, 1280))
        resized_image = resize_transform2(image)
        resized_image_tensor2 = self.transform(resized_image)

        transformed_rs = torch.zeros([self.frames, 3, self.resize, self.resize])
        crop = transforms.RandomCrop((self.resize, self.resize))

        # 分成5*5个224×224的patch
        for i in range(5):  # 行
            for j in range(5):  # 列
                # 计算每个块的左上角坐标
                left = j * 256
                upper = i * 256
                right = left + 256
                lower = upper + 256

                transformed_rs[i * 5 + j] = crop(resized_image_tensor2[:, upper:lower, left:right])

        # print(transformed_rs.shape)

        return transformed_rs, Image_name


def main(config):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = DIQAModel.DIQA_model()

    pretrained_weights_path = config.Model_weights_path
    if pretrained_weights_path:
        model.load_state_dict(torch.load(pretrained_weights_path, map_location=device, weights_only=True), strict=False)
        print(f"成功加载预训练权重: {pretrained_weights_path}")

    model.to(device)
    model.float()

    transformations = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    testset = ImageDataset_Diqa(config.videos_dir, config.datainfo, transformations, config.resize, config.frames, config.feat_dir)
    test_loader = torch.utils.data.DataLoader(testset, batch_size=1, shuffle=False, num_workers=config.num_workers)

    with torch.no_grad():
        model.eval()
        session_start_test = time.time()
        y_output1 = np.zeros([len(testset)])
        y_output2 = np.zeros([len(testset)])
        y_output3 = np.zeros([len(testset)])
        names = []

        for i, (rs,Image_name) in enumerate(test_loader):
            rs = rs.to(device)
            names.append(Image_name[0])
            outputs1, outputs2, outputs3 = model(rs)
            y_output1[i] = outputs1.item()
            y_output2[i] = outputs2.item()
            y_output3[i] = outputs3.item()
            print(y_output1[i], y_output2[i], y_output3[i])

        session_end_test = time.time()

    data = {
        'Image': names,
        'overall': y_output1,
        'sharpness': y_output2,
        'color_fidelity': y_output3,
    }

    df = pd.DataFrame(data)
    df.to_csv('prediction.csv', index=False)
    print(f'CostTime: {session_end_test - session_start_test:.4f}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    parser.add_argument('--videos_dir', type=str, default='/data/coding/test/res')
    parser.add_argument('--datainfo', type=str, default='/data/coding/test/test.csv')
    parser.add_argument('--frames', type=int, default=25)
    parser.add_argument('--Model_weights_path', type=str, default='weights/GoldenChef_Diqa_model.pth', help='模型权重路径')
    parser.add_argument('--resize', type=int, default=224)
    parser.add_argument('--num_workers', type=int, default=8)
    parser.add_argument('--feat_dir', type=str, default='/data/coding/test/test/features') 
    config = parser.parse_args()
    main(config)
